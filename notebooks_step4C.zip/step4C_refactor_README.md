# Step 4C refactor notes

Base: Step 4B, with two targeted fixes.

## What changed

1. `ParallelDistributions_step4C.wl`
   - Keeps the same coarse parallel strategy: one full `Vacuum` / `Fitted` mode block per task.
   - Does not parallelize individual `mT`/`y` grid points.
   - Does not parallelize inside `NIntegrate`.
   - Fixes the step4B structural validation by checking only the public keys required by the plotting notebooks.
   - Returns explicit rules from subkernels, then constructs the top-level association from those rules.

2. `MultiplicityTables_step4C.wl`
   - Keeps multiplicity computation in `Distributions`.
   - Keeps optional parallelization over complete multiplicity cells.
   - Fixes the `MissingMultiplicity` table issue by replacing internal list keys with string keys.
   - Reason: in Wolfram Language, `Lookup[assoc, {a,b,c,d}, default]` means lookup several keys, not one compound list key.

## Physics / numerics

No physical formula, branching factor, integration range, mass model, normalization, or `NIntegrate` option was intentionally changed.

## Recommended first run

Use conservative settings first:

```mathematica
useParallelDistributions = True;
useParallelMultiplicities = True;
maxParallelKernels = 2;
parallelDistributionGranularity = "ModeBlock";
```

Then compare against the known good step3D/step4B serial outputs.

## Diagnostics after Distributions

```mathematica
ValueQ[AllDistributionTablesByMode]
Keys[AllDistributionTablesByMode]
ValueQ[StableParticleMultiplicityTable]
StableParticleMultiplicityTable
```

Expected top-level keys:

```mathematica
{"Vacuum", "Fitted"}
```

If a parallel run still falls back, set:

```mathematica
useParallelDistributions = False;
useParallelMultiplicities = True;
```

This isolates distribution parallelization from multiplicity parallelization.
