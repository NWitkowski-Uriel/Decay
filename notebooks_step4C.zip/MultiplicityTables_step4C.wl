(* ::Package:: *)
(* ============================================================ *)
(* STABLE PARTICLE MULTIPLICITY TABLES -- STEP 4C                *)
(* ============================================================ *)
(* Multiplicity bookkeeping is computed during Distributions.     *)
(* Step 4C fixes the step4B MissingMultiplicity table issue by    *)
(* using unambiguous string keys for the internal Association.     *)
(* Mathematica Lookup treats a list as a list of keys, not as one  *)
(* compound key, so step4B list-keys were displayed as Missing.   *)
(*                                                              *)
(* Parallelization is only over complete multiplicity cells. No   *)
(* yield formula, branching factor, mass model, or NIntegrate      *)
(* option is changed.                                             *)
(* ============================================================ *)

If[Length[DownValues[primordialYield]] == 0 || Length[DownValues[NPDPP]] == 0,
  Print[Style["ERROR: Intro has not been evaluated. Run Intro before Distributions.", Red]];
  Abort[];
];

If[! ValueQ[useParallelMultiplicities], useParallelMultiplicities = True];
If[! ValueQ[maxParallelKernels], maxParallelKernels = 2];

ClearAll[
  yieldTypesByMode, ytModelLabels, ytModes, ytColumnPairs, yieldTypeFor,
  ytFiniteNumberQ, ytSafeN, ytPretty, ytExpectedLabel, ytGrid, ytModelModeHeader,
  primordialMultiplicityDirect, correctionMultiplicityDirect, totalMultiplicityDirect,
  multiplicityTaskKeys, multiplicityKeyString, multiplicityTaskValue,
  computeMultiplicityValuesSerial, computeMultiplicityValuesParallel,
  computeMultiplicityValuesSafe,
  primordialMultiplicity, correctionMultiplicity, totalMultiplicity,
  multiplicityComponentValue, multiplicityPairedRow,
  stableMultiplicityRowsForParticle, stableMultiplicityTableForParticle,
  StableParticleMultiplicityRowsByParticle,
  StableParticleMultiplicityTablesByParticle,
  StableParticleMultiplicityTable, StableParticleMultiplicityRows,
  ProtonMultiplicityTable, PionPlusMultiplicityTable, PionMinusMultiplicityTable
];

ytModelLabels = {"Dirac", "BW", "Cugnon", "PhaseShift"};
ytModes = {"Vacuum", "Fitted"};
ytColumnPairs = Flatten[Table[{label, mode}, {label, ytModelLabels}, {mode, ytModes}], 1];

yieldTypesByMode = <|
  "Vacuum" -> <|
    "Dirac" -> "Dirac",
    "BW" -> "BreitWigner",
    "Cugnon" -> "Cugnon",
    "PhaseShift" -> "PhaseShift"
  |>,
  "Fitted" -> <|
    "Dirac" -> "Dirac",
    "BW" -> "BreitWignerFitted",
    "Cugnon" -> "CugnonFitted",
    "PhaseShift" -> "PhaseShiftFitted"
  |>
|>;

yieldTypeFor[mode_String, label_String] := yieldTypesByMode[mode][label];

ytFiniteNumberQ[x_] := NumericQ[x] && FreeQ[N[x], Indeterminate | ComplexInfinity | DirectedInfinity[_]];

ytSafeN[expr_] := Module[{res},
  res = Quiet @ Check[N[expr], Missing["Failed"]];
  If[ytFiniteNumberQ[res], N[res], Missing["NonNumeric"]]
];

ytPretty[x_?NumericQ] := NumberForm[N[x], {Infinity, 3}, ExponentFunction -> (Null &), NumberPadding -> {"", "0"}];
ytPretty[x_] := x;

ytExpectedLabel[1] := "1";
ytExpectedLabel[1.] := "1";
ytExpectedLabel[2/3] := "2/3";
ytExpectedLabel[1/3] := "1/3";
ytExpectedLabel[x_] := x;

ytGrid[rows_] := Grid[
  Map[Which[# === 1 || # === 1. || # === 2/3 || # === 1/3, ytExpectedLabel[#], NumericQ[#], ytPretty[#], True, #] &, rows, {2}],
  Frame -> All,
  Alignment -> Center,
  Background -> {None, {LightGray, None}}
];

ytModelModeHeader[prefix_List] := Join[prefix, Flatten[Table[{label <> " Vacuum", label <> " Fitted"}, {label, ytModelLabels}]]];

primordialMultiplicityDirect["Proton"] := ytSafeN[primordialYield[\[Mu]P, mp, gN]];
primordialMultiplicityDirect["PionPlus"] := ytSafeN[primordialYield[\[Mu]Pip, mpi, gPi]];
primordialMultiplicityDirect["PionMinus"] := ytSafeN[primordialYield[\[Mu]Pim, mpi, gPi]];

correctionMultiplicityDirect[type_String, "Proton"] := ytSafeN[NPDPP[type] + NPDP[type] + NPD0[type]];
correctionMultiplicityDirect[type_String, "PionPlus"] := ytSafeN[NPiDPP[type] + (1/3) decayYieldGeneric[type, \[Mu]Dp, mpi, mn, gPi]];
correctionMultiplicityDirect[type_String, "PionMinus"] := ytSafeN[NPiDM[type] + (1/3) decayYieldGeneric[type, \[Mu]D0, mpi, mp, gPi]];

totalMultiplicityDirect[type_String, particle_String] := Module[{prim, corr},
  prim = primordialMultiplicityDirect[particle];
  corr = correctionMultiplicityDirect[type, particle];
  If[ytFiniteNumberQ[prim] && ytFiniteNumberQ[corr], N[prim + corr], Missing["BadTotal"]]
];

multiplicityTaskKeys = Flatten[
  Table[{particle, contribution, mode, label},
    {particle, {"Proton", "PionPlus", "PionMinus"}},
    {contribution, {"Primordial", "Correction", "Total"}},
    {mode, ytModes},
    {label, ytModelLabels}
  ],
  3
];

(* Use a string key. Lookup[assoc, {a,b,c,d}] means "look up four separate keys",
   not "look up the compound list key {a,b,c,d}". *)
multiplicityKeyString[{particle_String, contribution_String, mode_String, label_String}] :=
  StringRiffle[{particle, contribution, mode, label}, "|"];

multiplicityTaskValue[{particle_String, "Primordial", mode_String, label_String}] := primordialMultiplicityDirect[particle];
multiplicityTaskValue[{particle_String, "Correction", mode_String, label_String}] := correctionMultiplicityDirect[yieldTypeFor[mode, label], particle];
multiplicityTaskValue[{particle_String, "Total", mode_String, label_String}] := totalMultiplicityDirect[yieldTypeFor[mode, label], particle];

computeMultiplicityValuesSerial[] := Association[(multiplicityKeyString[#] -> multiplicityTaskValue[#]) & /@ multiplicityTaskKeys];

computeMultiplicityValuesParallel[] := Module[{target, missing, rules, ok},
  target = Max[1, Min[maxParallelKernels, $ProcessorCount]];
  missing = target - Length[Kernels[]];
  If[missing > 0, LaunchKernels[missing]];
  ParallelEvaluate[$HistoryLength = 0];
  Print["Parallel multiplicity build enabled: one complete multiplicity cell per task."];
  DistributeDefinitions["Global`"];
  rules = Quiet @ Check[
    ParallelMap[(multiplicityKeyString[#] -> multiplicityTaskValue[#]) &, multiplicityTaskKeys, Method -> "CoarsestGrained"],
    $Failed
  ];
  ok = MatchQ[rules, {(_String -> _)..}] && Length[rules] == Length[multiplicityTaskKeys];
  If[! TrueQ[ok],
    Print[Style["Parallel multiplicity build returned an invalid rule list. Falling back to serial multiplicity build.", Red]];
    computeMultiplicityValuesSerial[],
    Association[rules]
  ]
];

computeMultiplicityValuesSafe[] := If[TrueQ[useParallelMultiplicities] && IntegerQ[maxParallelKernels] && maxParallelKernels > 1,
  computeMultiplicityValuesParallel[],
  computeMultiplicityValuesSerial[]
];

StableParticleMultiplicityValues = computeMultiplicityValuesSafe[];

primordialMultiplicity[particle_String] := Lookup[StableParticleMultiplicityValues, multiplicityKeyString[{particle, "Primordial", "Vacuum", "Dirac"}], primordialMultiplicityDirect[particle]];
correctionMultiplicity[type_String, particle_String] := correctionMultiplicityDirect[type, particle];
totalMultiplicity[type_String, particle_String] := totalMultiplicityDirect[type, particle];

multiplicityComponentValue[contribution_String, particle_String, mode_String, label_String] :=
  Lookup[StableParticleMultiplicityValues, multiplicityKeyString[{particle, contribution, mode, label}], Missing["MissingMultiplicity"]];

multiplicityHeader = ytModelModeHeader[{"Contribution"}];

multiplicityPairedRow[particle_String, contribution_String] := Module[{values},
  values = Map[Function[pair, multiplicityComponentValue[contribution, particle, pair[[2]], pair[[1]]]], ytColumnPairs];
  {contribution, Sequence @@ values}
];

stableMultiplicityRowsForParticle[particle_String] := (multiplicityPairedRow[particle, #] &) /@ {"Primordial", "Correction", "Total"};

stableMultiplicityTableForParticle[particle_String] := ytGrid @ Prepend[stableMultiplicityRowsForParticle[particle], multiplicityHeader];

StableParticleMultiplicityRowsByParticle = Association @ Table[particle -> stableMultiplicityRowsForParticle[particle], {particle, {"Proton", "PionPlus", "PionMinus"}}];
StableParticleMultiplicityTablesByParticle = Association @ Table[particle -> stableMultiplicityTableForParticle[particle], {particle, {"Proton", "PionPlus", "PionMinus"}}];

StableParticleMultiplicityRows = Flatten[
  Table[With[{particle = particle, contribution = contribution}, Join[{particle}, multiplicityPairedRow[particle, contribution]]],
    {particle, {"Proton", "PionPlus", "PionMinus"}}, {contribution, {"Primordial", "Correction", "Total"}}],
  1
];

StableParticleMultiplicityTable = ytGrid @ Prepend[StableParticleMultiplicityRows, Join[{"Particle"}, multiplicityHeader]];

ProtonMultiplicityTable = StableParticleMultiplicityTablesByParticle["Proton"];
PionPlusMultiplicityTable = StableParticleMultiplicityTablesByParticle["PionPlus"];
PionMinusMultiplicityTable = StableParticleMultiplicityTablesByParticle["PionMinus"];

Print["Stable-particle multiplicity tables prepared in Distributions."];
