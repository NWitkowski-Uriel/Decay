(* ::Package:: *)

(* ============================================================ *)
(* STEP 4C -- CONTROLLED COARSE PARALLEL DISTRIBUTION BUILD      *)
(* ============================================================ *)
(* This file is loaded by Distributions_step4C.nb after all       *)
(* low-level spectrum builders have been defined. It parallelizes *)
(* only complete Vacuum/Fitted mode blocks. Points of one         *)
(* spectrum and all NIntegrate internals remain serial.           *)
(*                                                              *)
(* Step 4C fixes the step4B structural-validation problem: the    *)
(* validator now checks only the public key structure that the     *)
(* plotting notebooks require, rather than imposing AssociationQ  *)
(* on subobjects whose exact internal type is notebook-dependent. *)
(* ============================================================ *)

If[! ValueQ[useParallelDistributions], useParallelDistributions = True];
If[! ValueQ[maxParallelKernels], maxParallelKernels = 2];
If[! ValueQ[parallelDistributionGranularity], parallelDistributionGranularity = "ModeBlock"];

ClearAll[
  analysisParallelEnabledQ,
  analysisEnsureParallelKernels,
  analysisDistributeDefinitionsOnce,
  buildDistributionModeBlock,
  validDistributionModeBlockQ,
  validDistributionTablesQ,
  computeDistributionModeBlockRule,
  computeAllDistributionTablesSerial,
  computeAllDistributionTablesParallel,
  computeAllDistributionTablesSafe
];

analysisParallelDefinitionsDistributed = False;

analysisParallelEnabledQ[] :=
  TrueQ[useParallelDistributions] &&
    MemberQ[{"ModeBlock", "Mode"}, parallelDistributionGranularity] &&
    IntegerQ[maxParallelKernels] && maxParallelKernels > 1;

analysisEnsureParallelKernels[] := Module[{target, running, missing},
  target = Max[1, Min[maxParallelKernels, $ProcessorCount]];
  running = Length[Kernels[]];
  missing = target - running;
  If[missing > 0, LaunchKernels[missing]];
  ParallelEvaluate[$HistoryLength = 0];
];

analysisDistributeDefinitionsOnce[] := Module[{},
  If[! TrueQ[analysisParallelDefinitionsDistributed],
    Print["Distributing current Global` definitions to subkernels..."];
    DistributeDefinitions["Global`"]; 
    ParallelEvaluate[$HistoryLength = 0];
    analysisParallelDefinitionsDistributed = True;
  ];
];

(* This is intentionally the same mode-block structure as in step3D. *)
buildDistributionModeBlock[mode_String] := Module[{delta, corr, corrTot},
  Print["========== Building Distributions mode: ", mode, " =========="];
  delta = buildDeltaTablesForMode[mode];
  corr = buildCorrectionTablesForMode[mode];
  corrTot = buildCorrectedTablesForMode[mode, corr];
  <|
    "Mode" -> mode,
    "PrimordialMt" -> PrimordialTables["Mt"],
    "PrimordialY" -> PrimordialTables["Y"],
    "DeltaMt" -> delta["Mt"],
    "DeltaY" -> delta["Y"],
    "CorrectionMt" -> corr["Mt"],
    "CorrectionY" -> corr["Y"],
    "CorrectedMt" -> corrTot["Mt"],
    "CorrectedY" -> corrTot["Y"]
  |>
];

validDistributionModeBlockQ[mode_String, block_Association] := Module[{required},
  required = {"Mode", "PrimordialMt", "PrimordialY", "DeltaMt", "DeltaY",
    "CorrectionMt", "CorrectionY", "CorrectedMt", "CorrectedY"};
  AllTrue[required, KeyExistsQ[block, #] &] && block["Mode"] === mode
];
validDistributionModeBlockQ[_, _] := False;

validDistributionTablesQ[tables_Association] := Module[{modes},
  modes = {"Vacuum", "Fitted"};
  AllTrue[modes, KeyExistsQ[tables, #] && validDistributionModeBlockQ[#, tables[#]] &]
];
validDistributionTablesQ[_] := False;

computeDistributionModeBlockRule[mode_String] := mode -> buildDistributionModeBlock[mode];

computeAllDistributionTablesSerial[] := <|
  "Vacuum" -> buildDistributionModeBlock["Vacuum"],
  "Fitted" -> buildDistributionModeBlock["Fitted"]
|>;

computeAllDistributionTablesParallel[] := Module[{modes, rules, assoc},
  modes = {"Vacuum", "Fitted"};
  Print["Controlled parallel distribution build enabled."];
  Print["Granularity: one full Vacuum/Fitted mode block per kernel; no NIntegrate internals are parallelized."];
  Print["maxParallelKernels = ", maxParallelKernels];
  analysisEnsureParallelKernels[];
  analysisDistributeDefinitionsOnce[];

  (* Return rules directly from subkernels. This avoids ambiguous reconstruction
     with AssociationThread and makes the output type explicit. *)
  rules = Quiet @ Check[
    ParallelMap[computeDistributionModeBlockRule, modes, Method -> "CoarsestGrained"],
    $Failed
  ];

  If[rules === $Failed || ! MatchQ[rules, {(_String -> _Association)..}],
    Print[Style["Parallel distribution build returned an invalid rule list. Falling back to serial build.", Red]];
    Return[computeAllDistributionTablesSerial[]];
  ];

  assoc = Association[rules];
  If[validDistributionTablesQ[assoc],
    Print["Parallel distribution build passed public-structure validation."];
    assoc,
    Print[Style["Parallel distribution output failed public-structure validation. Falling back to serial build.", Red]];
    Print["Returned top-level keys: ", Keys[assoc]];
    computeAllDistributionTablesSerial[]
  ]
];

computeAllDistributionTablesSafe[] := If[
  analysisParallelEnabledQ[],
  computeAllDistributionTablesParallel[],
  Print["Serial distribution build enabled."];
  computeAllDistributionTablesSerial[]
];

AllDistributionTablesByMode = computeAllDistributionTablesSafe[];
