# Step 3D refactor

This version rolls back the Step 3C cache layer and uses Step 3B as the cache-free baseline.

Changes:

1. `AllDistributionTablesByMode` is again produced directly by `Distributions_step3D.nb`; no `.mx` cache is used.
2. Stable-particle multiplicity tables are computed after the distribution tables, via `MultiplicityTables_step3D.wl` loaded from `Distributions_step3D.nb`.
3. `Yield_Test_step3D.nb` no longer recomputes primordial/correction/total multiplicities. It only checks that the public multiplicity tables exist and then continues with ratio/normalization diagnostics.
4. No physics formulas, integration limits, mass distributions, branching factors, or `NIntegrate` kernels were intentionally changed.

Run order:

1. `Intro_step3D.nb`
2. `PairFit_step3D.nb`
3. `Distributions_step3D.nb`
4. `Yield_Test_step3D.nb`
5. `Primordial_Plots_step3D.nb`
6. `Correction_Plots_step3D.nb`
7. `Comparison_Plots_step3D.nb`
8. `Ratios_Plots_step3D.nb`

Keep `MultiplicityTables_step3D.wl` in the same directory as the notebooks.
