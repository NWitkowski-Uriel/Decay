(* ::Package:: *)
(* ============================================================ *)
(* STABLE PARTICLE MULTIPLICITY TABLES                          *)
(* ============================================================ *)
(* Step 3D policy: multiplicity bookkeeping is computed during   *)
(* Distributions, not inside Yield Test. This shifts the expensive*)
(* primordial/correction/total yield evaluation to the notebook   *)
(* that already prepares physical distribution tables. Yield Test  *)
(* then only reads these public objects and validates ratios.      *)
(* No NIntegrate kernels, integration ranges, mass distributions,  *)
(* branching factors, or physics formulas are changed here.        *)
(* ============================================================ *)

If[Length[DownValues[primordialYield]] == 0 || Length[DownValues[NPDPP]] == 0,
  Print[Style["ERROR: Intro has not been evaluated. Run Intro before Distributions.", Red]];
  Abort[];
];

ClearAll[
  yieldTypesByMode, ytModelLabels, ytModes, ytColumnPairs, yieldTypeFor,
  ytFiniteNumberQ, ytSafeN, ytPretty, ytExpectedLabel, ytGrid, ytModelModeHeader,
  primordialMultiplicity, correctionMultiplicity, totalMultiplicity,
  multiplicityComponentValue, multiplicityPairedRow,
  stableMultiplicityRowsForParticle, stableMultiplicityTableForParticle,
  StableParticleMultiplicityRowsByParticle,
  StableParticleMultiplicityTablesByParticle,
  StableParticleMultiplicityTable, StableParticleMultiplicityRows,
  ProtonMultiplicityTable, PionPlusMultiplicityTable, PionMinusMultiplicityTable
];

ytModelLabels = {"Dirac", "BW", "Cugnon", "PhaseShift"};
ytModes = {"Vacuum", "Fitted"};
ytColumnPairs = Flatten[Table[{label, mode}, {label, ytModelLabels}, {mode, ytModes}], 1];

yieldTypesByMode = <|
  "Vacuum" -> <|
    "Dirac" -> "Dirac",
    "BW" -> "BreitWigner",
    "Cugnon" -> "Cugnon",
    "PhaseShift" -> "PhaseShift"
  |>,
  "Fitted" -> <|
    "Dirac" -> "Dirac",
    "BW" -> "BreitWignerFitted",
    "Cugnon" -> "CugnonFitted",
    "PhaseShift" -> "PhaseShiftFitted"
  |>
|>;

yieldTypeFor[mode_String, label_String] := yieldTypesByMode[mode][label];

ytFiniteNumberQ[x_] := NumericQ[x] && FreeQ[N[x], Indeterminate | ComplexInfinity | DirectedInfinity[_]];

ytSafeN[expr_] := Module[{res},
  res = Quiet @ Check[N[expr], Missing["Failed"]];
  If[ytFiniteNumberQ[res], N[res], Missing["NonNumeric"]]
];

ytPretty[x_?NumericQ] := NumberForm[
  N[x],
  {Infinity, 3},
  ExponentFunction -> (Null &),
  NumberPadding -> {"", "0"}
];
ytPretty[x_] := x;

ytExpectedLabel[1] := "1";
ytExpectedLabel[1.] := "1";
ytExpectedLabel[2/3] := "2/3";
ytExpectedLabel[1/3] := "1/3";
ytExpectedLabel[x_] := x;

ytGrid[rows_] := Grid[
  Map[
    Which[
      # === 1 || # === 1. || # === 2/3 || # === 1/3,
        ytExpectedLabel[#],
      NumericQ[#],
        ytPretty[#],
      True,
        #
    ] &,
    rows,
    {2}
  ],
  Frame -> All,
  Alignment -> Center,
  Background -> {None, {LightGray, None}}
];

ytModelModeHeader[prefix_List] := Join[
  prefix,
  Flatten[Table[{label <> " Vacuum", label <> " Fitted"}, {label, ytModelLabels}]]
];

primordialMultiplicity["Proton"] :=
  ytSafeN[primordialYield[\[Mu]P, mp, gN]];

primordialMultiplicity["PionPlus"] :=
  ytSafeN[primordialYield[\[Mu]Pip, mpi, gPi]];

primordialMultiplicity["PionMinus"] :=
  ytSafeN[primordialYield[\[Mu]Pim, mpi, gPi]];

correctionMultiplicity[type_String, "Proton"] :=
  ytSafeN[NPDPP[type] + NPDP[type] + NPD0[type]];

correctionMultiplicity[type_String, "PionPlus"] :=
  ytSafeN[NPiDPP[type] + (1/3) decayYieldGeneric[type, \[Mu]Dp, mpi, mn, gPi]];

correctionMultiplicity[type_String, "PionMinus"] :=
  ytSafeN[NPiDM[type] + (1/3) decayYieldGeneric[type, \[Mu]D0, mpi, mp, gPi]];

totalMultiplicity[type_String, particle_String] := Module[{prim, corr},
  prim = primordialMultiplicity[particle];
  corr = correctionMultiplicity[type, particle];
  If[ytFiniteNumberQ[prim] && ytFiniteNumberQ[corr],
    N[prim + corr],
    Missing["BadTotal"]
  ]
];

multiplicityComponentValue["Primordial", particle_String, mode_String, label_String] :=
  primordialMultiplicity[particle];

multiplicityComponentValue["Correction", particle_String, mode_String, label_String] :=
  correctionMultiplicity[yieldTypeFor[mode, label], particle];

multiplicityComponentValue["Total", particle_String, mode_String, label_String] :=
  totalMultiplicity[yieldTypeFor[mode, label], particle];

multiplicityHeader = ytModelModeHeader[{"Contribution"}];

multiplicityPairedRow[particle_String, contribution_String] := Module[{values},
  values = Map[
    Function[pair, multiplicityComponentValue[contribution, particle, pair[[2]], pair[[1]]]],
    ytColumnPairs
  ];
  {contribution, Sequence @@ values}
];

stableMultiplicityRowsForParticle[particle_String] :=
  (multiplicityPairedRow[particle, #] &) /@ {"Primordial", "Correction", "Total"};

stableMultiplicityTableForParticle[particle_String] :=
  ytGrid @ Prepend[
    stableMultiplicityRowsForParticle[particle],
    multiplicityHeader
  ];

StableParticleMultiplicityRowsByParticle = Association @ Table[
  particle -> stableMultiplicityRowsForParticle[particle],
  {particle, {"Proton", "PionPlus", "PionMinus"}}
];

StableParticleMultiplicityTablesByParticle = Association @ Table[
  particle -> stableMultiplicityTableForParticle[particle],
  {particle, {"Proton", "PionPlus", "PionMinus"}}
];

StableParticleMultiplicityRows = Flatten[
  Table[
    With[{particle = particle, contribution = contribution},
      Join[{particle}, multiplicityPairedRow[particle, contribution]]
    ],
    {particle, {"Proton", "PionPlus", "PionMinus"}},
    {contribution, {"Primordial", "Correction", "Total"}}
  ],
  1
];

StableParticleMultiplicityTable = ytGrid @ Prepend[
  StableParticleMultiplicityRows,
  Join[{"Particle"}, multiplicityHeader]
];

ProtonMultiplicityTable = StableParticleMultiplicityTablesByParticle["Proton"];
PionPlusMultiplicityTable = StableParticleMultiplicityTablesByParticle["PionPlus"];
PionMinusMultiplicityTable = StableParticleMultiplicityTablesByParticle["PionMinus"];

Print["Stable-particle multiplicity tables prepared in Distributions."];
